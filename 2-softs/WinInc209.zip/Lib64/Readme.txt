
if this directory is empty (or contains just UUID.LIB), run
..\Def64\makelibs.bat to create the most important Win64 import libraries.
